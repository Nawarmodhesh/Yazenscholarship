<?php
// الاتصال بقاعدة البيانات
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mail";
$conn = new mysqli($servername, $username, $password, $dbname);

// فحص اتصال قاعدة البيانات
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
if(isset($_POST['sent']) ){
// إدراج البيانات في قاعدة البيانات

$sql = $conn ->prepare("SELECT * FROM users WHERE email =:email");
$username = $_POST['username'];
$email = $_POST['email'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);
$verification_code = $code; // الرمز المرسل إلى البريد الإلكتروني
$sql = "INSERT INTO users (username, email, password, verification_code)
VALUES ('$username', '$email', '$password', '$verification_code')";

if ($conn->query($sql) === TRUE) {
  echo "New record created successfully";
} else {
  echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
}
?>

<!DOCTYPE Html>
<html lang="en">
<head>
    <meta charset="UTL-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name ="veiwport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">

    <title> conact us</title>

</head>
<body>
<div class="container" dir="rtl" style="text-align:right importaint">
    <form action="send.php" method="post"  enctype="multipart/form-data">
        <h1>REGESTER</h1>
         الاسم الاول:<input class= " form-control" type="text" name="username" required/>
        <br>
       
        الايميل:<input  class= " form-control" name="email" type="email" id="email" placeholder="enter your email" required>
        <br>
        الرمز:<input class= " form-control" name="password" type="text" id="password" placeholder="enter your passwod" required>
        <br>
        <input  class= " form-control" type="file" name="file" required/> 
        <input class= " btn btn-dark" name="submit" type="submit" value="sent" required>
        <a class="btn btn-warning " href="login/login.php">home </a>


    </form>
    </div>
</body>
</html>

