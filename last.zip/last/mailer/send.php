<?php


require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;


//$mail->SMTPDebug=0;
if(isset($_POST['submit'])){
    $email = $_POST['email'];




$mail = new PHPMailer;


    $mail->isSMTP();                                           
    $mail->Host       = 'smtp.gmail.com';
    $mail->SMTPAuth   = true;       
    $mail->Username   = 'yazenscholarship2023@gmail.com';                    
    $mail->Password   = 'wvnqaaaoistzpehy';                             
    $mail->SMTPSecure = 'tls';            
    $mail->Port       = 587;                                   
    $mail->setFrom('yazenscholarship2023@gmail.com');
    $mail->addAddress($email); 

  
    $mail->isHTML(true);  
    $code= mt_rand(99999, 999999);                               
    $mail->Subject = 'كود التحقق:';
    

    $mail->Body    = 'YAZEN SCHOLARSHIP :'  .$code;

    $mail->send();
    echo 'Message has been sent ' .$code;

}

    $username = "root";
$password =""; 
$database = new PDO ("mysql:host = localhost; dbname=mail;",$username,$password);
?>

    


