<?php


?>

<!DOCTYPE Html>
<html lang="en">
<head>
    <meta charset="UTL-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name ="veiwport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">

    <title> conact us</title>

</head>
<body>
<div class="container" dir="rtl" style="text-align:right importaint">
    <form action="send.php" method="post"  enctype="multipart/form-data">
        <h1>REGESTER</h1>
         الاسم الاول:<input class= " form-control" type="text" name="fname" required/>
        <br>
        الاسم الوسط:<input class= " form-control" type="text" name="mname" required/>
        <br>
      اللقب:<input class= " form-control" type="text" name="lname" required/>
        <br>
        
     العمر:<input class= " form-control" type="date" name="age" required/>
      <br>
      العنوان:<input class= " form-control" type="text" name="addres" required/>
        <br>
        رقم الجوال:<input class= " form-control" type="text" name="phone" required/>
        <br>
        الايميل:<input  class= " form-control" name="email" type="email" id="email" placeholder="enter your email" required>
        <br>
        الرمز:<input class= " form-control" name="password" type="text" id="password" placeholder="enter your passwod" required>
        <br>
        <input  class= " form-control" type="file" name="file" required/> 
        <input class= " btn btn-dark" name="submit" type="submit" value="sent" required>
        <a class="btn btn-warning " href="login/login.php">home </a>


    </form>
    </div>
</body>
</html>








    
<?php

$username = "root";
$password =""; 
$database = new PDO ("mysql:host = localhost; dbname=yazen;",$username,$password);//






if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Check if file was uploaded without errors
    if (isset($_FILES['file']) && $_FILES['file']['error'] === UPLOAD_ERR_OK) {
        $file = $_FILES['file'];

        // Validate file size
        if ($file['size'] > 5242880) { // 5MB (in bytes)
            echo 'Error: File size exceeds the allowed limit.';
        } else {
            // Validate file type
            $allowedTypes = ['image/jpeg', 'image/png', 'image/gif'];
            if (in_array($file['type'], $allowedTypes)) {
                $uploadPath = 'uploads/' . basename($file['name']);

                // Move the uploaded file to the desired location
                if (move_uploaded_file($file['tmp_name'], $uploadPath)) {
                    echo 'File uploaded successfully.';
                } else {
                    echo 'Error: Failed to move uploaded file.';
                }
            } else {
                echo 'Error: Only JPEG, PNG, and GIF files are allowed.';
            }
        }
    } else {
        echo 'Error: File upload failed.';
    }
}

if(isset($_POST['sent']) ){
    $checkEmail = $database ->prepare("SELECT * FROM users WHERE EMAIL =:EMAIL");
    $email = $_POST ['email'];
    $checkEmail ->bindParam("EMAIL",$email);
    $checkEmail ->execute();
    if($checkEmail->rowCount()>0){
        echo '<div class="alert alert-danger" role="alert">
        ه>ا الحساب مستخدم سابقا</div>';
    }else{
        $fname =filter_var($_POST['fname'],FILTER_SANITIZE_STRING);
        $mname =filter_var($_POST['mname'],FILTER_SANITIZE_EMAIL);
        $lname =filter_var($_POST['lname'],FILTER_SANITIZE_EMAIL);
        $addres =filter_var($_POST['adders'],FILTER_SANITIZE_EMAIL);
        $phone=filter_var($_POST['phone'],FILTER_SANITIZE_EMAIL);
        $email=filter_var($_POST['email'],FILTER_SANITIZE_EMAIL);

        $password =filter_var($_POST['password'],FILTER_SANITIZE_STRING);
        $verification_code = $code;


        $age =($_POST['age']);
       


        $addUser = $database->prepare("INSERT INTO customer(FIRST_NAME,MIDEL_NAME,LAST_NAME,ADDRES,PHONE_NUM, AGE ,EMAIL,PASSWORD,FILE,verification_code ) 
        VALUES(:FIRST_NAME,:MIDEL_NAME,:LAST_NAME,:ADDRES,:PHONE_NUM:AGE,:EMAIL,:PASSWORD,:FILE,verification_code)");
        $addUser->bindParam("FIRST_NAME",$fname);
        $addUser->bindParam("MIDEL_NAME",$mname);
        $addUser->bindParam("LAST_NAME",$lname);
        $addUser->bindParam("ADDRES",$addres);
        $addUser->bindParam("PHONE_NUM",$phone);
        $addUser->bindParam("AGE",$age);
        $addUser->bindParam("EMAIL",$email);
        $addUser->bindParam("PASSWORD",$password);
       // $key = md5(date("h:i:s"));
        //$addUser->bindParam("KEY",$key);
        

       if($addUser -> execute()){
           echo '<div class="alert alert-success" role="alert">
            تم انشاء حساب بنجاح</div>';

           // require_once "mail.php";
           // $mail->addAddress($email);
           // $mail->Subject = "رمز تحقق من بريد الكتروني";
           // $mail->Body = '<h1> شكرا لتسجيلك في موقعنا</h1>'
           // . "<div> رابط تحقق من حساب" . "<div>" . 
           // "<a href='http://localhost:4433/app/active.php?code=".$securityCode  . "'>
           //  " . "http://localhost:4433/app/active.php?code=" .$securityCode . "</a>";
            //;
            //$mail->setFrom("nawarmodhesh2022@gmail.com", "Yazen ScholarShip");
            //$mail->send();

        }else{
           echo '<div class="alert alert-danger" role="alert">
            حدث خطا غير متوقع</div>';

        }

        







       
    }

}
?>



?>