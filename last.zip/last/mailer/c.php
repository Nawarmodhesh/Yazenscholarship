<?php
// الاتصال بقاعدة البيانات
$servername = "localhost";
$username = "username";
$password = "";
$dbname = "mail";
$conn = new mysqli($servername, $username, $password, $dbname);

// فحص اتصال قاعدة البيانات
if ($conn->connect_error) {
  die("Connection failed: " . $conn->connect_error);
}
if(isset($_POST['sent']) ){
// التحقق من الرمز المدخل
$email = $_POST['email'];
$verification_code = $_POST['verification_code'];
$sql = "SELECT * FROM user WHERE email='$email' AND verification_code='$verification_code'";
$result = $conn->query($sql);

if ($result->num_rows == 1) {
  // إذا كان الرمز صحيحًا، فقم بتحديث حقل التحقق في قاعدة البيانات
  $sql = "UPDATE users SET verified=1 WHERE email='$email'";
  if ($conn->query($sql) === TRUE) {
   echo "Email verified successfully";
  } else {
    echo "Error updating record: " . $conn->error;
  }
} else {
  echo "Invalid verification code";
}

$conn->close();
}
?>

الرمز:<input class= " form-control" name="password" type="text" id="password" placeholder="enter your passwod" required>
        <br>
        <input class= " btn btn-dark" name="sent" type="submit" value="sent" required>
        <a class="btn btn-warning " href="login/login.php">home </a>