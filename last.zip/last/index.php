<!DOCTYPE html>
<html lang="en">
<head>
    <title>SCHOLARSHIP</title>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- رابط Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    
</head>
<body>

<div class="container bg-secondary text-white">
  <div class="row align-items-center">
    <div class="col-md-6">
      <h2 class="logo">Yazen</h2>
      <h1 class="top"><br><br><span>Yazen</span> Scholarship</h1>
      <p class="par"></p>
      <button class="btn btn-primary"><a href="#">JOIN US</a></button>
    </div>
    <div class="col-md-6">
      <form method="post" action="" class="form">
        <h2 class="text-white">Login Here</h2>
        <div class="form-group">
          <input type="email" name="email" placeholder="Enter Email Here" id="email" class="form-control" required>
        </div>
        <div class="form-group">
          <input type="password" name="password" placeholder="Enter Password Here" id="password" class="form-control" required>
        </div>
        <div class="form-group">
          <button type="submit" class="btn btn-primary" name="login">Login</button>
        </div>
        <p class="link text-white">Don't have an account? <a href="register.php">Sign up here</a></p>
      </form>
    </div>
  </div>
</div>>
</div>
</div>

<?php
// Database connection
$servername = "localhost";
$username = "root";
$password = "";
$dbname = "mail";

$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Login process
if (isset($_POST['login'])) {
    $email = $_POST['email'];
    $password = $_POST['password'];

    $sql = "SELECT * FROM user WHERE email='$email' AND password='$password'";
    $result = mysqli_query($conn, $sql);

    if (mysqli_num_rows($result) == 1) {
        session_start();
        $_SESSION['email'] = $email;
        header("Location: home.php");
        exit();
    } else {
        echo "<div class='container mt-3 alert alert-danger'>Invalid email or password</div>";
    }
}

mysqli_close($conn);
?>

<!-- رابط Bootstrap JS -->
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>

</body>
</html>