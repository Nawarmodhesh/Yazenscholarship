<?php
// Include PHPMailer library
//require 'PHPMailer/PHPMailerAutoload.php';
require 'PHPMailer/src/Exception.php';
require 'PHPMailer/src/PHPMailer.php';
require 'PHPMailer/src/SMTP.php';

use PHPMailer\PHPMailer\PHPMailer;
use PHPMailer\PHPMailer\SMTP;
use PHPMailer\PHPMailer\Exception;
// Database connection settings
$host = 'localhost';
$username = 'root';
$password = '';
$dbname = 'mail';

// Connect to the database
$conn = mysqli_connect($host, $username, $password, $dbname);

// Check if the connection was successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the form was submitted
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    // Get the form data
    $name =filter_var($_POST['name'],FILTER_SANITIZE_STRING);
    $mname =filter_var($_POST['mname'],FILTER_SANITIZE_STRING);
    $lname =filter_var($_POST['lname'],FILTER_SANITIZE_STRING);
    $age=$_POST['age'];
     $addres =filter_var($_POST['addres'],FILTER_SANITIZE_STRING);
     $phone=filter_var($_POST['phone'],FILTER_SANITIZE_STRING);
     $email=filter_var($_POST['email'],FILTER_SANITIZE_EMAIL);
   
    $password =$_POST['password'];

    // Hash the password
    $hashed_password = password_hash($password, PASSWORD_DEFAULT);
   
   

    // Insert the user data into the database
    $sql = "INSERT INTO users (name,mname,lname,age,addres,phone, email, password) VALUES ('$name','$mname','$lname','$age','$addres','$phone', '$email', '$hashed_password')";
    if (mysqli_query($conn, $sql)) {
        // Generate a random confirmation code
        $confirmation_code = bin2hex(random_bytes(16));

        // Update the user data with the confirmation code
        $sql = "UPDATE users SET confirmation_code = '$confirmation_code' WHERE email = '$email'";
        mysqli_query($conn, $sql);

        // Send the confirmation email
        $mail = new PHPMailer;

        // Set up SMTP
        $mail->isSMTP();
        $mail->Host = 'smtp.gmail.com';
        $mail->SMTPAuth = true;
        $mail->Username = 'yazenscholarship2023@gmail.com';
        $mail->Password = 'wvnqaaaoistzpehy';
        $mail->SMTPSecure = 'tls';
        $mail->Port = 587;

        // Set up email content
        $mail->setFrom('yazenscholarship2023@gmail.com', 'yazenscholarship');
        $mail->addAddress($email);
        $mail->Subject = 'Confirm your registration';
        $mail->Body = "Please click on the following link to confirm your registration: http://yazenscholarship2023.com/confirm.php?code=$confirmation_code";

        // Send the email
        if (!$mail->send()) {
            echo 'Message could not be sent.';
            echo 'Mailer Error: ' . $mail->ErrorInfo;
        } else {
            echo 'Message has been sent'  ;
        }
    } else {
        echo 'Error: ' . mysqli_error($onn);
    }

    // Close the database connection
    mysqli_close($conn);
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Registration Form</title>
    <meta charset="UTL-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name ="veiwport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css">

</head>
<body>
<div class="container" dir="rtl" style="text-align:right importaint">
    <h1>Registration Form</h1>
    <form method="POST" enctype="multipart/form-data">
        <label>الاسم الاول:</label><br>
        <input type="text" name="name" class= " form-control" required><br>
        الاسم الوسط:<input class= " form-control" type="text" name="mname" required/>
        <br>
        اللقب:<input class= " form-control" type="text" name="lname" required/>
        <br>
        العمر:<input class= " form-control" type="date" name="age" required/>
        <br>
      العنوان:<input class= " form-control" type="text" name="addres" required/>
        <br>
        رقم الجوال:<input class= " form-control" type="text" name="phone" required/>
        <br>
        <label>الايميل:</label><br>
        <input type="email" name="email"  class= " form-control" required><br>
        <label>الرمز</label><br>
        <input type="password" name="password" class= " form-control" required><br>
        <br>
        <input  class= " form-control" type="file" name="file" required/> 
        
        <a class="btn btn-warning " href="login/login.php">home </a>
        <button type="submit" name="submit" class= " btn btn-dark">Register</button>
    </form>
</body>
</html>