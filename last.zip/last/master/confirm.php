<?php
// Database connection settings
$host = 'localhost';
$username = 'root';
$password = '';
$dbname = 'mail';

// Connect to the database
$conn = mysqli_connect($host, $username, $password, $dbname);

// Check if the connection was successful
if (!$conn) {
    die("Connection failed: " . mysqli_connect_error());
}

// Check if the confirmation code was provided
if (isset($_GET['code'])) {
    $code = $_GET['code'];

    // Update the user data to confirm registration
    $sql = "UPDATE users SET confirmed = 1 WHERE confirmation_code = '$code'";
    if (mysqli_query($conn, $sql)) {
        echo 'Your registration has been confirmed. You can now log in.';
    } else {
        echo 'Error: ' . mysqli_error($onn);
    }

    // Close the database connection
    mysqli_close($conn);
} else {
    echo 'No confirmation code provided.';
}
?>